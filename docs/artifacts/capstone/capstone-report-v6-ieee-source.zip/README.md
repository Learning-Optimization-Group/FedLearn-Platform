# IEEE capstone manuscript

Compile capstone-report-v6-ieee.tex from this directory with a TeX distribution that includes IEEEtran. All six vector figures are included. The architecture figure and thirteen references are embedded in the source.

Commands:

    latexmk -pdf capstone-report-v6-ieee.tex

Or:

    tectonic capstone-report-v6-ieee.tex

The manuscript follows the requested section order in IEEE conference mode on US Letter paper.
