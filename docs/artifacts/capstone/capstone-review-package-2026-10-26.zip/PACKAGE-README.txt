Start with CONSOLIDATION.md or capstone-final-report-v5-working.pdf.
This is a local review package of reading materials and public aggregates.
The defense outline is editable content, not an exported PowerPoint or rehearsed talk.
Source-code and ancillary repository links require the original checkout; this is not a self-contained training archive.
No raw arrays, patient mappings, saved heads or private launch configuration are included.
No advisor approval, publication, submission, external validation or production privacy is implied.
