# Capstone work checklist

Updated 26 October 2026. Scope: the capstone and the FedLearn foundations it uses.
This is the current completion checklist; older reports/decks remain historical
records. Checked items have completed evidence; an unchecked item may be underway.
The final capstone is **not complete**. The fixed 360-cell study has finished and
independent and original-source analyses agree. Study review and its validation
correction are complete. Effusion A1–A23 and the bounded dashboard checkpoint are completed
historical work; the fresh-seed ByzFL comparison and integrated research report are complete; assessed
deliverables remain open. The full integrated dashboard checklist is separate.

## Live checkpoint

**Research frozen:** the user confirmed no approved access or unused cohort. The maximum 48-hour feasibility check stopped at the access gate, with no external evaluation or replacement study. Use the [consolidation index](CONSOLIDATION.md), [claim/evidence map](consolidation-evidence-map-2026-10-26.md), [defense outline](defense-outline-2026-10-26.md) and [advisor review packet](advisor-review-packet-2026-10-26.md). The outline is content-only; exported slides, actual rehearsal, advisor approval and submission remain open.

**26 October status:** [report v5](capstone-final-report-v5-working.md), [PDF](capstone-final-report-v5-working.pdf) and HTML are complete at 14 pages with five figures. All 52 nonprivate CPU cells completed across Mac-only and Mac/G14/Orin placements, using 3/6/24/80 logical clients: 320 rounds and 13,180 acknowledged fits. Numerical comparisons passed; all five-round three-host jobs were slower end to end. The [results](multihost-results-2026-10-26.md) and [verification](multihost-verification-2026-10-26.json) define the scope. Do not rerun this matrix to seek a favorable result.

Clean CPU reproduction passed in three fresh environments, with 164 bounded profile checks and a tracked-files-only source-export qualification. It has [hash-locked setup and generated qualification commands](clean-reproduction.md). The [clean reproduction receipt](clean-reproduction-verification-2026-10-26.json) is the authority for its final verified outcome; it is separate from the frozen medical studies. No new medical fits, holdout/test evaluation or external messages are part of that work.

The current remaining deliverables are the advisor/rubric decisions, presentation, final consistency checks and submission/rehearsal below. Earlier unchecked research entries are historical proposals, not instructions to launch new experiments.

**25 October status:** all five accepted [research-remediation phases](../../superpowers/plans/2026-10-24-capstone-evidence-remediation.md)
are complete: claim/seed corrections, exact native/ByzFL qualification,126 audited pilot cells,
196 audited finalist cells and an integrated11-page working report with four figures/PDF/HTML.
See the [completion audit](remediation-completion-audit-2026-10-25.md) and [report](capstone-final-report-v3-working.md).
The primary private-clean projection gain is+0.0192, seedt95[+0.0110,+0.0273]; the pilot overstated
its fresh-seed point, and clean no-noise utility loses0.0149. The holdout stays closed.
Assessed deliverables, advisor requirements and any later submission-oriented editorial revision
remain separate. Older preparation statuses below are historical and superseded where noted.

**Follow-up target:** Effusion, selected on 22 October. Do not substitute the historical
any-finding labels or the mobile pneumonia task. A10 opened the internal holdout once;
new studies use permitted training/selection data only.

### Historical research and implementation ledger

- [x] Audit all fourteen candidate conditions in the existing development cohort
  without fitting or test scoring. [Feasibility audit](condition-feasibility-audit-2026-10-20.md):
  independent counts agree; positive-patient scarcity and misleading majority
  accuracy identified. No condition or new model has been selected by this audit.
- [x] Prepare a source-bound medical feature candidate without NIH fitting:
  [CheXpert DenseNet-121 check](medical-backbone-candidate-2026-10-21.md). Exact
  checkpoint/library pinned; two synthetic CPU inputs yield finite 1,024-value
  features with exact fresh-process replay. Nine reproduction tests pass.
  At that preparation checkpoint the 512-wide legacy cache was unchanged and disease accuracy
  had not yet been measured; later Effusion results are listed below.
- [x] Check real development inputs for that candidate without fitting:
  [eight-image probe](medical-input-probe-2026-10-22.md). Pinned cache/manifests,
  whole-set patient separation, label-free hash selection, raw-byte and decoded-pixel
  audit bindings and an explicit grayscale contract pass; 8 × 1,024 frozen features
  are finite and replay byte-identically. No test manifest, labels, fitting or scores.
- [x] Select the condition and define the prediction purpose, labels, baseline acceptance measures and a genuinely
  untouched final evaluation; do not tune to the already examined NIH test results.
  **22 Oct:** user selected `Effusion` and a locked internal holdout. Label-blind,
  patient-whole 50/50 validation carve locked (2,800/2,800 patients; receipt
  `083aa7ce…c794`). [Protocol v1](effusion-baseline-protocol-v1.md) drafted and
  frozen on the user's approval (22 Oct).
- [x] Run the frozen centralized gate on development data:
  [gate v1 result](effusion-gate-v1-result-2026-10-22.md). Versioned 1,024-wide R1
  cache built (77,725 images, none refused) and replay-verified; 20/20 fits converged.
  Selection AUROC R0 0.822, R1 0.829; ΔAUROC +0.007 [−0.004, +0.018], so **the gate
  failed on criterion (a)**; both exceed the 0.80 floor. Federated baseline not started.
  **Decision pending:** amend to proceed on R0 or R1, or add bounded fine-tuning.
- [ ] Audit and improve a bounded centralized learning baseline on development data.
  The [initial audit](learning-baseline-audit-2026-10-20.md) is complete: development
  payload identities/statistics checked, no centralized NIH comparison found, and
  representation/optimization/federation effects remain unresolved. No new fitting
  or test scoring has been performed; the prospective diagnostic is next.
- [x] Qualify a matched federated baseline without DP or attacks:
  [result](effusion-federated-v1-result-2026-10-22.md), on R1 by amendment A2 with the
  A3 reading rule committed first. Federated 0.797 vs central-SGD 0.800 (seed means;
  −0.004), production engine, 5 seeds, no refusals. Gap to the convex head is
  recipe-limited (central control clipped every round).
- [x] Central-DP sweep with a declared R0 width arm (A4) and secure-aggregation
  equivalence/overhead (A5): [result](effusion-privacy-secure-v1-result-2026-10-22.md).
  Client-level ε 8/4/1 costs R1 0.035/0.088/0.232 AUROC; the 2×-wide head pays more at
  every ε (width contrast +0.007/+0.017/+0.051, all intervals exclude 0; noise-to-signal
  ≈√2). LightSecAgg is utility-equivalent (−1e-7 AUROC) at 158× upload; secure +
  trimmed mean/median/Krum marked unavailable. Local DP still needs qualification.
- [x] Audit privacy/security readiness against source and fresh controls:
  [readiness report](privacy-security-readiness-2026-10-20.md), 218 checks passed.
  Local DP exists in the generic engine but is excluded from the qualified NIH
  path; secure aggregation is on DeComFL's scalar channel. No new NIH runs.
- [ ] After the learning gate, qualify local DP with separate client/server noise
  fields and explicit clipping/release accounting. Preserve historical record semantics.
- [ ] Choose and qualify a matched secure/plain training path before attributing
  performance differences to secure aggregation; mark incompatible combinations unavailable.
- [ ] Freeze a supported follow-up comparison of central DP, local DP and secure
  aggregation, including clean controls and explicit privacy/trust/compatibility scope.
  Central DP and secure aggregation done (A4/A5); local DP done (A11:
  [result](effusion-local-dp-r0-v1-result-2026-10-22.md), near chance at ε ≤ 8, needs about ε 128 to
  match central ε 8).
- [x] Run the bounded attack study across declared seeds, retaining all outcomes:
  [A9 result](effusion-attacks-r0-v1-result-2026-10-22.md), 100/100 cells usable.
- [x] One-time holdout evaluation of the frozen list (A10):
  [holdout result](effusion-holdout-v1-result-2026-10-22.md). FedAvg 0.836 vs centralised
  0.835 AUROC; DP ε 8/4/1 0.763/0.715/0.580; sensitivity held about 0.91 at frozen thresholds.
- [x] Recipe studies (A7 clean, A8 DP) and platform changes: DP fail-closed fix (`5fad502`),
  `DPFedAvg` + planner (`969755a`); see [practical guidance](fedlearn-practical-guidance.md).
- [x] Build absolute-performance and attack-drop heatmaps with uncertainty and costs:
  `figures/effusion-attack-heatmaps-v1.*`, rendered from the pinned record by `repro/plot_effusion_attacks.py`.
- [x] Add the Effusion R0 workload to the Simulation Lab (framework bundle + workload, Lab
  contract with measured recipes, API, UI). A Lab run reproduces the capstone A7 run exactly;
  real-browser pass recorded in
  [simulation-lab-effusion-browser-verification-2026-10-22.json](simulation-lab-effusion-browser-verification-2026-10-22.json).
- [x] Literature check of robust and private FL against what we ran:
  [review](literature-review-robust-private-fl-2026-10-22.md), with a ranked shortlist. Progress, 22 October:
  - **#1 Production DP adjacency.** [Analysis](production-dp-adjacency-analysis-2026-10-22.md).
    The `--dp-adjacency` option, the eval-card field and the fixed-denominator refusal shipped in `edad4aa`.
  - **#2 Exact GDP accountant.** Shipped as `--dp-accountant gdp`.
    [A13](effusion-gdp-calibration-r0-v1-result-2026-10-22.md): +0.017 AUROC at ε 4 for the same claim.
  - **#7 Fewer DP releases.** [A15](effusion-dp-rounds-r0-v1-result-2026-10-22.md): negative with a random-init
    head, whose cause led to
    [A17](effusion-zero-head-r0-v1-result-2026-10-22.md). A zero-initialised head adds +0.019 to +0.20 AUROC under DP.
    The ε 4 cost against clean A7 falls from 0.124 to 0.081 (exploratory best, T = 5).
  - **#3/#4 Small-k trimming and stronger attacks:** [A14](effusion-strong-attacks-r0-v1-result-2026-10-22.md).
    Without DP, Fang's attack at 20% costs the mean 0.155 and the median 0.063.
    Under the DP-oriented recipe and nominal aggregate-input noise calibration, mean beats the tested trimming variants. These oracle attacked cells do not inherit a complete client-data DP guarantee.
  - **#5 Canary audit:** [A16](effusion-canary-audit-r0-v1-result-2026-10-22.md) was underpowered
    (the clean control failed), and A18 was withdrawn before running.
    A mechanism check over 7,235 recorded DP rounds found 0 mismatches.
  - **#6 Non-IID:** [A19](effusion-noniid-r0-v1-result-2026-10-22.md). Clean moderate-skew points are close. Strong skew lowers private AUROC 0.038; the additional privacy cost is about 0.03253,
    and under Fang's attack the mean falls to chance while the median keeps +0.129.
  - **#8 Noise-aware filtering:** [A20](effusion-local-filter-r0-v1-result-2026-10-22.md). It fixes A12 at no cost (9/120,000 honest drops).
    Protocol-following attackers are capped at 0.015–0.059.
    [A21](effusion-local-ks-r0-v1-result-2026-10-22.md): norm-matching attackers evade it (up to 0.54).
    A KS test is free but only partial (0.07–0.32 residual), these two filters do not establish robust protection; neither verified-noise necessity nor sufficiency was established.
  - **#10 Stronger encoder:** [A22](effusion-encoder-gate-v1-result-2026-10-23.md). Only DINOv2 passed the gate (+0.013, lower bound +0.0007);
    both chest-X-ray DenseNets failed. Under DP it keeps about +0.01; original patient intervals include zero, while the epsilon-8 paired-seed interval is positive on the fixed selection cohort, and its DP-cost difference from R0 is unresolved; the experiment does not isolate a causal width effect.
  - **#9 Distributed DP:** [A23](effusion-distributed-dp-r0-v1-result-2026-10-23.md). Skellam over coded LightSecAgg has close calibrated noise to central RDP at 16 bits, with unresolved utility differences and unqualified server/client collusion. Four clip-skipping clients out of 80 drive it below chance (0.25),
    so input validation is necessary; collusion/noise and transport assumptions also need qualification. Coded shares: 4.4× a plain upload at 16 bits, against 81× uncoded.
  - **Shortlist partially covered.** The25October pilots now test one-step released-history clipping, nonprivate bucketing under simulated skew, scalar output-perturbed ERM and fixed/public dimension reduction. Full client-momentum methods, real site shift and private bucketing remain untested. A16 was unsuccessful empirical validation. See the24 October phased-remediation plan.
- [x] Zero-initialised-head option for DP frozen-head runs: `--head-init zero` (user approved, 22 October).
  Platform defaults chosen by the user ('smart defaults, no schema'): the backend passes `--dp-accountant gdp` for every DP run,
  and `--head-init zero` for DP runs on FROZEN_HEAD/OVA_LP that are not continued runs. Backend gate: 1,218 tests, 0 failures,
  84.17% line coverage. There is no per-project UI switch (by choice).
- [ ] Complete and browser-verify the integrated simulator, including persistence,
  ownership, live progress, stop/reopen, comparison, heatmaps and research export.

The Spring API checkpoint passes 32 focused checks and the full backend gate:
1,207 tests, no skips, 84.09% line coverage. An earlier admin-login HTTP EOF did not
recur in isolation or the instrumented full run; its cause is unresolved, not fixed.
React and actual browser acceptance remain open. Preserve the tested checkpoint
while prioritizing learning quality.
The API is committed locally at `53d60fc`; no public push or merge is implied.

| Item | Current evidence |
| --- | --- |
| Working branch | `capstone`, isolated worktree |
| Tested source | `3baea7d` — fixed NIH study runner and score analysis |
| Full framework verification | Study source: 2,076 passed/81.66%; later worker: 2,183 passed/79.82%; 14 deselected; thread exceptions treated as errors |
| Focused runner/analysis verification | 68 passed; both Important review findings reproduced before correction |
| Backup | Delivery commit `4e80033`, exact Git bundle and 4,729 source/evidence files hash-verified on Orin; original raw-study backup retained |
| Main study | **360/360 qualified**, 7,200 rounds; 0 failed, timed out or unrun |
| Run status | Original process exited normally; all four fixed families completed once |
| Study verification | 360 models/both splits replayed, 148 source files and 16 allocations verified; primary D=+0.002266150, paired 95% CI [+0.000704398,+0.003827901], conditional on fixed cohorts |
| Results | [Study report](nih-phase2-study-v1-report.md), 12 tables/3,202 rows and six rendered figures; additional reader and corrected-checker audit passed; study review completed |

The terminal original study now has a separate second-device backup: all 3,964
files hash-verified, including final models/scores/proofs/configs/logs. Earlier source,
cache, historical and first 80-cell checkpoints remain preserved. The reviewed
audit/report/figures and exact delivery source checkpoint now also have a verified
4,729-file private backup. Charging resumed during capture
after battery operation; observed timing interpretation discloses that transition
and the in-flight backup as background load.

The study index and verification receipts are authoritative. The overview and
claim register now reflect the completed execution and reconciled outcomes; older
implementation entries are explicitly historical. Original execution source stays
pinned at 3baea7d. Reviewed delivery documents are committed at 4e80033.

## Completed — preservation, scope and existing research

- [x] Create a dedicated `capstone` branch/worktree and preserve the original
  simulation research history.
- [x] Integrate the merged FedLearn baseline while retaining mobile/XGBoost work.
- [x] Preserve the earlier 945 exploratory Milestone 2 run records, notes,
  configurations and presentation assets in a private recovery backup.
- [x] Write the previously missing [Milestone 2 report](capstone-milestone-2-report.md).
- [x] Consolidate the [capstone plan](../../../wikis/capstone/README.md), schedule,
  scope boundaries and [final-report claim/evidence map](final-report-evidence-map.md).
- [x] Preserve source plus ignored research evidence on a second device; verify
  file hashes and the exact Git branch head, rather than assuming copying succeeded.
- [x] Draft an [advisor title/scope message](advisor-title-confirmation-draft.md).
  Drafting is complete; advisor approval and sending remain separate open actions.

## Completed — NIH data and learning foundation

- [x] Prepare the **No Finding = 0 / any listed finding = 1** task; keep it separate
  from the mobile pneumonia-only task.
- [x] Verify the metadata, official lists and all 112,120 image decodes.
- [x] Audit patient/image membership and exact RGB duplicates; detect that patient
  separation alone left content leakage in the original preparation.
- [x] Independently confirm the reported duplicate/contradictory-label groups.
- [x] Quarantine 111 development images from nine non-test patients; preserve the
  complete official test set and retain the failed original audit.
- [x] Qualify curated splits: **68,650 training / 17,763 validation / 25,596 test**
  images, with separate patients across these groups.
- [x] Extract and verify frozen pretrained ResNet-18 features, with pinned model,
  transformation, source, manifest and payload identities.
- [x] Add the NIH workload and whole-patient simulated-client allocation; preserve
  natural prevalence and require explicit validation/test selection.
- [x] Preserve historical workload behavior and verify selected earlier reproduction
  anchors after integrating the platform baseline.

Evidence: [NIH audit](nih-data-audit-2026-10-19.md),
[qualified features/cohort](nih-frozen-features-2026-10-19.md).

## Completed — exploratory learning and methodological corrections

- [x] Run and report the first no-DP validation pilot and a separate 1,000-client,
  two-round execution check. The latter demonstrates simulation execution only.
- [x] Identify float32 probability-saturation error in AUROC; introduce versioned
  float64 logit margins and preserve old records unchanged.
- [x] Run the bounded optimization pilot; identify that cohort size also changes
  local minibatch trajectories, so nominal image exposure is insufficient alone.
- [x] Qualify the eighty-client E7/R20 schedule across three fixed seeds.
- [x] Compare matched image exposure with E1/R140: similar exploratory validation
  utility and seven times the modeled payload; retain the trajectory caveat.
- [x] Audit attack knowledge and diagnostic release boundaries. Restrict the main
  study to attacks using their own data/updates; distinguish model DP accounting
  from protection of research logs, seeds and patient identities.
- [x] Correct participation accounting; distinguish submitted, admitted, accepted
  and aggregated clients and prevent false completed-round claims.
- [x] Add a core qualification wrapper enforcing permitted recipes, complete fixed
  cohorts, round counts and explicit evaluation identity.
- [x] Qualify all four trainable head sizes in the bounded cost probe: 1,026,
  4,122, 65,922 and 263,682 parameters. This is a cost/execution check, not convergence.
- [x] Run and independently reconcile the 12-cell exploratory privacy/attack
  qualification: 240 rounds, clean/sign-flip/label-flip, mean/trimmed mean,
  no DP/central epsilon 4.
- [x] Publish exploratory findings with caveats: trimming helps the attacked no-DP
  result in that seed, but gives lower absolute DP utility; matched epsilon also
  gives trimming 5/3 the coordinate noise SD in the eighty-client comparison.

Evidence: [v1](nih-validation-pilot-v1-report.md),
[v2](nih-optimization-pilot-v2-report.md), [v3](nih-schedule-pilot-v3-report.md),
[head costs](nih-head-cost-probe-v1-report.md),
[mechanism qualification](nih-mechanism-qualification-v1-report.md),
[core checks](core-execution-qualification.md),
[privacy boundary](privacy-output-boundary-audit.md).

## Completed — confirmatory study preparation

- [x] Prospectively freeze the [360-cell protocol](nih-phase2-study-v1-protocol.md)
  before official-test classifier scoring: 240 primary, 72 head, 24 cohort and
  24 clipping cells, with ten new primary seeds.
- [x] Freeze the primary contrast, final-round endpoint, paired interval method,
  missing-cell rules, resource budgets and per-run privacy assumptions.
- [x] Freeze the nine-image ambiguous-content sensitivity mask while preserving
  primary official-test membership.
- [x] Capture the actual qualified final server state using owned CPU parameters.
- [x] Save and reload final models and aligned validation/test logits, float64
  margins, labels and identities; validate record/cache/model/source bindings.
- [x] Implement the fixed isolated-process runner: all configurations persisted
  before launch, retained failures, source proofs, timing/cost gates and integrity stop.
- [x] Implement separate NumPy score analysis: tied-score AUROC, threshold transfer,
  inverse-patient weighting, mask sensitivity and complete-pair primary inference.
- [x] Make saved-study analysis reopen raw artifacts and recompute summaries;
  reject edited scores, stale identities and missing artifact hashes.
- [x] Reproduce and fix both launch blockers from final review: uncontrolled parent
  CPU threads and malformed protocol/configuration failures continuing the study.
- [x] Pass focused/full regression gates, commit source and verify the private backup.
- [x] Launch the fixed study once on 20 October; persist all 360 initial entries,
  keep the Mac awake and avoid concurrent tests/source edits during timing capture.

Evidence: [artifact contract](final-state-score-artifact-contract.md),
[runner contract](nih-phase2-runner-contract.md),
[implementation plan](../../superpowers/plans/2026-10-20-capstone-confirmatory-study.md).

## Completed — dashboard demonstration design

- [x] Choose integration into the existing FedLearn dashboard and write a concrete
  [Simulation Lab design](../../superpowers/specs/2026-10-20-simulation-lab-design.md).
  Its fresh builder check found no material unanswered questions; the
  [implementation plan](../../superpowers/plans/2026-10-20-simulation-lab.md) specifies
  the Python worker, persistent Spring ownership/lifecycle, React workflow and
  actual browser evidence. Implementation/testing follows the audited study report.

Implementation has begun: the bounded worker, choice resolver and canonical
finite/tagged record writer pass **107 focused tests**. Two lifecycle review findings
were reproduced and corrected; an installed-wheel control completed two real
synthetic-cache rounds. The full framework gate passed **2,183 tests**, 14 deselected, with 79.82% coverage.
The backend/API checkpoint also passes its full gate. The React implementation
passes its component/service/route checks and frontend release gates. Actual
authenticated browser-to-worker, keyboard and responsive acceptance now also pass;
see the verification receipt and demonstration guide below.

- [x] Implement and qualify the [bounded Simulation Lab worker](simulation-lab-worker-contract.md),
  including actual subprocess lifecycle and isolated installed-wheel verification.
  One minor oversized-integer CLI error-formatting issue remains documented.
- [x] Implement and qualify the [owned persistent Spring API](simulation-lab-api-contract.md),
  including real cookie/PostgreSQL authorization, process supervision, stop/restart,
  safe persisted research exports and the opt-in numerical worker controls.
  All 1,207 backend tests passed with 84.09% line coverage. Synthetic execution
  controls do not establish NIH model quality. One busy-response link minor and
  the unreproduced admin-login transport failure remain documented.


- [x] Implement the dashboard route, recipe review/start, actual-round polling,
  stop/reopen/export, matched-workload comparisons and historical-study page.
  The 21 October checkpoint passes **175 frontend tests**, lint and production
  build, with **57.59% line coverage**. Both tagged-nonfinite chart crashes were
  reproduced before correction. The report link now names the actual HTML file;
  all ten public manifest entries were fetched and hash-checked in the browser.
  These checks do not establish authenticated UI-to-worker execution or learning
  quality. The original Markdown download retains repository-relative references,
  disclosed on its download page; a self-contained Markdown package is deferred.
- [x] Finish authenticated keyboard/responsive verification and the real
  browser-to-API-to-NIH-worker demonstration, including ownership and stop/export.
  The [21 October receipt](simulation-lab-browser-verification-2026-10-21.json)
  binds two completed three-round jobs and one stopped two-of-twenty-round job.
  The disabled-workload phase returned 503 and retained all three jobs. A real
  screenshot exposed clipped mobile controls despite an initially green width
  check; responsive navigation and stronger checks now pass. **179 frontend tests**,
  lint/build and 57.74% line coverage pass.
- [x] Write the [live demonstration and explicitly labelled replay guide](simulation-lab-demo-guide.md).
- [ ] Verify off-device preservation of the new dashboard/browser checkpoint;
  local evidence is retained and the historical study already has verified backups.

## Study checks and remaining reporting

- [x] **Finish the single 360-cell execution:** all four families qualified once.
  Retain all outcomes and unrun cells; never replace failed cells to improve coverage.
- [x] **Independently reconcile the real evidence after capture:** committed source,
  configs, allocations, attackers, counts, checkpoint decoding, both split forwards,
  AUROC, privacy accounting, payload/FLOPs, timings and memory scope.
  The independent checker passed all 360 models and 7,200 rounds. The additional
  source-bound reader also reproduced the complete saved analysis. Review found one
  Important primary-summary validation gap; complete/partial/malformed regressions
  and a fresh all-model audit pass after its correction.
- [x] **Recompute the primary ten-seed effect and interval independently.** If any
  required component is missing, suppress the planned interval and report missingness.
- [x] Verify validation-selected threshold transfer, patient weighting and the
  frozen content-mask sensitivity results for every qualifying model.
- [x] Reconcile all 64 descriptive groups and matched head/cohort/clipping controls.
- [x] Write the main study report and create/render/check scientific figures and
  tables against the independently checked evidence.
- [x] Produce practical FedLearn recommendations with measured effect, cost,
  uncertainty, applicable assumptions and concrete implementation implications.
- [x] Update the current plan/evidence map and this checklist from actual outcomes;
  back up the new raw study, audit, figures and source checkpoint.

## Current delivery checklist

- [ ] Record advisor confirmation of exact title, contribution/scope, required format and presentation duration. The existing message draft has not been sent; do not assume approval.
- [x] Integrate the research narrative, uncertainty and limitations into report v5, 14 pages/five figures, with all numeric tables and reading copies verified. Earlier report versions remain preserved.
- [x] Complete and audit the bounded physical-host CPU extension; preserve its negative timing result and logical-versus-physical distinction.
- [x] Document fresh CPU environment setup, generated qualification, private launch schema and meaningful failure checks. Final verified outcomes are in the clean reproduction receipt, not inferred from documentation.
- [x] Retain primary-source literature review and scoped privacy/robustness comparisons. No matched NVIDIA FLARE or state-of-the-art superiority claim is established.
- [x] Implement and browser-verify the bounded Simulation Lab configuration, start/stop, progress/history and research export workflow. The physical-host qualification is a separate CLI path; do not present it as integrated dashboard orchestration.
- [ ] Export and render the final slide file from the completed editable defense outline/speaker notes. The outline includes the projection utility trade-off, failed private-centered default and actual CPU timing penalty; older decks remain historical. Presentation export is unavailable in the current session and is not claimed complete.
- [ ] Prepare and rehearse the live demonstration with a clearly labelled replay fallback; verify network/runtime readiness immediately before delivery.
- [ ] Apply advisor-required report/citation formatting and perform report/figures/deck/demo consistency checks.
- [ ] Finalize the shareable evidence package with data-access requirements; exclude raw models, patient identities, private endpoints and research diagnostics.
- [ ] Prepare final submission and delivery rehearsal. Advisor messaging, publication, push or merge requires separate explicit authorization.

## Research closure and deferred work

- [x] Apply the approved cohort feasibility gate. User-confirmed access failure ended the extension; no external evaluation was performed. Keep the existing holdout closed and retain the limitation in the defense.
- Deferred: further performance profiling. The negative CPU result is retained; a blocked cohort is not replaced with another experiment.
- Deferred: accelerator/deep-model studies, private distributed training, secure-aggregation hardening and additional framework/protocol baselines. None is an active consolidation task.

## Schedule and scope decisions

| Window | Focus |
| --- | --- |
| Now–2 November | Consolidate the frozen evidence, record advisor scope/format and export the defense presentation |
| 3–16 November | Rehearse the demonstration and talk; resolve advisor-required delivery corrections |
| 17–30 November | Final report, presentation and rehearsal |
| 1–5 December | Correction/reproduction buffer; stated deadline 5 December |

Keep the primary study, honest reporting and reproducibility ahead of GUI extras.
Local DP remains outside the historical any-finding matrix; Effusion A11/A12/A20/A21 later
investigated it with recipe-specific limits. New candidate scope follows the phased plan;
physical thousand-device deployment remains outside scope.
Mobile release/signing/production TLS remains parked while capstone work has priority.
There is no defensible single completion percentage: experiment preparation is
complete and the scientific result is measured and reconciled. The bounded dashboard and working report are verified; advisor-specific formatting, final presentation, submission and rehearsal remain open.
